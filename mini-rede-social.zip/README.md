# Mini Rede Social

Uma rede social simples feita com HTML, CSS e JavaScript puro. Funciona offline com PWA.

## Funcionalidades

- Publicar posts com texto e imagens
- Curtir posts
- Comentar posts
- Mensagens em tempo real
- Modo escuro/claro
- Pesquisa de posts
- Filtro de palavras inadequadas
- Perfis com iniciais coloridas
- Responsivo para mobile

## Como Usar

1. Abra o `index.html` no navegador.
2. Configure seu nome (opcional).
3. Publique posts e interaja!

## Hospedagem

### GitHub Pages (Recomendado)

1. Crie um repositório no GitHub (ex: `mini-rede-social`).
2. Faça upload dos arquivos: `index.html`, `app.js`, `manifest.json`, `sw.js`.
3. Vá em Settings > Pages.
4. Selecione branch `main` e salve.
5. O site ficará disponível em `https://seu-usuario.github.io/mini-rede-social/`.

### Netlify (Rápido)

1. Acesse [Netlify Drop](https://app.netlify.com/drop).
2. Arraste a pasta do projeto para o navegador.
3. O site será hospedado instantaneamente.

## Arquivos

- `index.html`: Estrutura da página
- `app.js`: Lógica JavaScript
- `manifest.json`: Configuração PWA
- `sw.js`: Service Worker para offline</content>
<parameter name="filePath">c:\Users\PC\Downloads\README.md