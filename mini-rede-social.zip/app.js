const badWords = ['palavrafeia1', 'palavrafeia2']; // Add bad words here

function filterWords(text) {
  badWords.forEach(word => {
    const regex = new RegExp(word, 'gi');
    text = text.replace(regex, '*'.repeat(word.length));
  });
  return text;
}

function getProfileColor(name) {
  const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
}

const badWords = ['merda', 'porra', 'caralho']; // Add bad words here

function filterWords(text) {
  badWords.forEach(word => {
    const regex = new RegExp(word, 'gi');
    text = text.replace(regex, '*'.repeat(word.length));
  });
  return text;
}

function getProfileColor(name) {
  const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
}
  let posts = JSON.parse(localStorage.getItem("posts") || "[]");
  let html = "";

  posts.reverse().forEach((p, index) => {
    if (searchTerm && !p.text.toLowerCase().includes(searchTerm.toLowerCase())) return;

    const profileColor = getProfileColor(p.author);
    const initial = p.author.charAt(0).toUpperCase();
    const imageHtml = p.image ? `<img src="${p.image}" alt="Post image" class="post-image">` : '';
    const commentsHtml = p.comments.map(c => `<div class="comment"><strong>${c.author}:</strong> ${filterWords(c.text)}</div>`).join('');

    html += `
      <div class="post">
        <div class="post-header">
          <div class="profile-pic" style="background-color: ${profileColor};">${initial}</div>
          <div class="post-info">
            <strong>${p.author}</strong> - ${p.timestamp}
          </div>
          <div class="post-actions">
            <div class="likes">
              <span>${p.likes} ❤️</span>
              <button class="like-btn" onclick="likePost(${posts.length - 1 - index})">Curtir</button>
            </div>
            <button class="delete-btn" onclick="deletePost(${posts.length - 1 - index})">Excluir</button>
          </div>
        </div>
        <div class="post-content">${filterWords(p.text)}</div>
        ${imageHtml}
        <div class="comments">
          ${commentsHtml}
          <div class="comment-input">
            <input type="text" placeholder="Comente..." id="comment-${posts.length - 1 - index}">
            <button onclick="addComment(${posts.length - 1 - index})">Comentar</button>
          </div>
        </div>
      </div>
    `;
  });

  document.getElementById("postList").innerHTML = html;
}

function addPost() {
  let text = document.getElementById("postText").value.trim();
  let image = document.getElementById("postImage").value.trim();
  if (!text) return;

  let name = document.getElementById("userName").value.trim() || "Anônimo";
  let posts = JSON.parse(localStorage.getItem("posts") || "[]");
  posts.push({ text: text, author: name, timestamp: new Date().toLocaleString('pt-BR'), likes: 0, image: image, comments: [] });
  localStorage.setItem("posts", JSON.stringify(posts));

  document.getElementById("postText").value = "";
  document.getElementById("postImage").value = "";
  loadPosts();
}

function clearAll() {
  if (confirm("Tem certeza que deseja limpar todos os posts e mensagens?")) {
    localStorage.removeItem("posts");
    localStorage.removeItem("msgs");
    loadPosts();
    loadMsgs();
  }
}

function loadMsgs() {
  let msgs = JSON.parse(localStorage.getItem("msgs") || "[]");
  let html = "";

  msgs.forEach(m => {
    html += `
      <div class="message">
        <strong>${m.author} (${m.timestamp}):</strong> ${filterWords(m.text)}
      </div>
    `;
  });

  document.getElementById("msgList").innerHTML = html;
}

function addMsg() {
  let text = document.getElementById("msgText").value.trim();
  if (!text) return;

  let name = document.getElementById("userName").value.trim() || "Anônimo";
  let msgs = JSON.parse(localStorage.getItem("msgs") || "[]");
  msgs.push({ text: text, author: name, timestamp: new Date().toLocaleTimeString('pt-BR') });
  localStorage.setItem("msgs", JSON.stringify(msgs));

  document.getElementById("msgText").value = "";
  loadMsgs();
}

function deletePost(index) {
  if (confirm("Tem certeza que deseja excluir este post?")) {
    let posts = JSON.parse(localStorage.getItem("posts") || "[]");
    posts.splice(index, 1);
    localStorage.setItem("posts", JSON.stringify(posts));
    loadPosts();
  }
}

function addComment(postIndex) {
  let commentText = document.getElementById(`comment-${postIndex}`).value.trim();
  if (!commentText) return;

  let name = document.getElementById("userName").value.trim() || "Anônimo";
  let posts = JSON.parse(localStorage.getItem("posts") || "[]");
  posts[postIndex].comments.push({ text: commentText, author: name });
  localStorage.setItem("posts", JSON.stringify(posts));

  document.getElementById(`comment-${postIndex}`).value = "";
  loadPosts();
}

function filterPosts() {
  const searchTerm = document.getElementById("searchInput").value;
  loadPosts(searchTerm);
}

function toggleTheme() {
  document.body.classList.toggle('dark-mode');
  const isDark = document.body.classList.contains('dark-mode');
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  document.querySelector('.theme-toggle').textContent = isDark ? '☀️' : '🌙';
}

// Load on page load
window.onload = () => {
  loadPosts();
  loadMsgs();

  // Load saved name
  let savedName = localStorage.getItem("userName");
  if (savedName) {
    document.getElementById("userName").value = savedName;
  }

  // Load theme
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-mode');
    document.querySelector('.theme-toggle').textContent = '☀️';
  }

  // Register service worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js');
  }
};

// Save name on input change
document.getElementById("userName").addEventListener("input", () => {
  let name = document.getElementById("userName").value.trim();
  localStorage.setItem("userName", name);
});